export class APIService {
    static LoginUser(body){
        return fetch(`http://127.0.0.1:8000/auth/login/token/`,{
            method:'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body:JSON.stringify(body)
        }).then(resp => resp.json())
    }

    static LogoutUser(token) {
        return fetch(`http://127.0.0.1:8000/auth/logout/`,{
            method:'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + {token}
            },
        }).then(resp => resp.json())
    }

    static RegisterUser(body){
        return fetch(`http://127.0.0.1:8000/auth/signup/`, {
            method:'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body:JSON.stringify(body)
        }).then(resp => resp.json())
    }
}

export default APIService;