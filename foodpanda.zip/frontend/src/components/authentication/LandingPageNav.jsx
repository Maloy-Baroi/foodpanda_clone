import React from 'react';
import './LandingPageNav.css';
import Logo from '../../images/static/Foodpanda-Logo.png';
import { Link } from 'react-router-dom';
import Logout from '../authentication/Logout';

const LoginNav = (props) => {
    return (
        <div>
            <nav className="navbar navbar-expand-lg bg-white">
                <div className="container-fluid">
                    <a className="navbar-brand" href="/">
                        <img src={Logo} alt="Foodpanda Logo" className="logo-image" />
                    </a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li className="nav-item language-conversion">
                                <a className="nav-link" href="/">bn</a>
                            </li>
                            <li className="nav-item language-conversion" style={{
                                "display": props.show
                            }}>
                                <Link className="nav-link" to="/">
                                    <svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" className="svg-stroke-container" width="24" height="24" viewBox="0 0 24 24">
                                        <g fill="none" fillRule="evenodd">
                                            <circle cx="12" cy="12" r="12" fill="#D70F64" fillRule="nonzero"></circle>
                                            <path fill="#FFF" fillRule="nonzero" d="M13.1818252 12.6666667C15.366281 12.6666667 17.1649879 14.3335701 17.3176726 16.4681904L17.3252836 16.6080555 17.3333337 17.0416667C17.3333337 17.1848516 17.2285728 17.3039382 17.0904223 17.3286342L17.0371901 17.3333333 6.96281056 17.3333333C6.81742783 17.3333333 6.69651331 17.2301562 6.67143827 17.0940941L6.666667 17.0416667 6.666667 16.75C6.666667 14.5418198 8.44636147 12.7430258 10.670143 12.6690344L10.8126768 12.6666667 13.1818252 12.6666667zM12.0000003 6C13.6568546 6 15.0000003 7.34314575 15.0000003 9 15.0000003 10.6568543 13.6568546 12 12.0000003 12 10.3431461 12 9.00000033 10.6568543 9.00000033 9 9.00000033 7.34314575 10.3431461 6 12.0000003 6z"></path>
                                        </g>
                                    </svg>
                                    <Logout />
                                </Link>
                            </li>
                            <li className="nav-item language-conversion" style={{
                                "display": props.show
                            }}>
                                <Link className="nav-link" to="/">
                                    <span className="cart-icon-img">
                                        <svg xmlns="http://www.w3.org/2000/svg" className="svg-stroke-container" width="24" height="24" aria-hidden="true" focusable="false">
                                            <path fill="#D70F64" d="M12 2.75a4.75 4.75 0 014.744 4.5h3.103a1 1 0 01.99 1.141l-1.714 12a1 1 0 01-.99.859H5.867a1 1 0 01-.99-.859l-1.714-12a1 1 0 01.99-1.141h3.103A4.75 4.75 0 0112 2.75zm5.559 14.75H6.44a.4.4 0 00-.396.457l.208 1.45a.4.4 0 00.396.343H17.35a.4.4 0 00.396-.343l.208-1.45a.4.4 0 00-.396-.457zm1.25-8.75H5.19a.4.4 0 00-.396.457l.922 6.45a.4.4 0 00.396.343h11.775a.4.4 0 00.396-.343l.922-6.45a.4.4 0 00-.396-.457zM12 4.25a3.251 3.251 0 00-3.193 2.638.305.305 0 00.3.362h5.796a.297.297 0 00.292-.35A3.251 3.251 0 0012 4.25z"></path>
                                        </svg>
                                    </span>
                                </Link>
                            </li>
                            
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    )
}

export default LoginNav;
