import React, { useEffect } from 'react'
import LandingPageNav from './LandingPageNav'
import { useNavigate } from 'react-router-dom'
import { Link } from 'react-router-dom'
import { useCookies } from 'react-cookie';
import './LandingPage.css'

function LandingPage() {
  const [token] = useCookies(['myToken']);
  const navigate = useNavigate();

  useEffect(() => {
    var user_token = token['myToken']
    console.log('Login User token is', user_token)
    console.log('Data type', typeof (token['myToken']))
    String(user_token) === 'undefined' ? navigate('/') : navigate('/main');
  }, [token])

  return (
    <div>
      <LandingPageNav show="none" />
      <div className="container">
        <div className="row">
          <div className="col-md-3"></div>
          <div className="col-md-6 justify-content-center">
            <div className='form-container'>
              <legend className="cl-neutral-primary f-24 fw-bold lh-regular mt-zero mb-xs welcome">
                Welcome!
              </legend>
              <p className="cl-neutral-primary f-14 fw-light mb-lg signin-info">Sign up or log in to continue</p>
              <div className="box-flex welcome-view__button-apple pb-md" data-testid="welcome-view-button-apple">
                <button className="button status--default button-apple full" type="button" data-testid="button-continue-with-apple" aria-live="polite">
                  <span className="button-apple__logo">
                    Continue with Apple
                  </span>
                </button>
              </div>
              <div className="box-flex welcome-view__button-google pb-md" data-testid="welcome-view-button-google">
                <button className="button status--default button-google full" type="button" data-testid="button-continue-with-google" aria-live="polite">
                  <span className="button-google__logo">
                    Continue with Google
                  </span>
                </button>
              </div>
              <div className="box-flex welcome-view__button-facebook pb-md" data-testid="welcome-view-button-facebook">
                <button className="button status--default button button-facebook full" type="button" data-testid="button-continue-with-facebook" aria-live="polite">
                  <span className="button-facebook__logo">
                    Continue with Facebook
                  </span>
                </button>
              </div>
              <div className="welcome-view__button-login pb-md full">
                <Link to="/login" style={{ "color": "#fff" }}>
                  <button data-testid="welcome-view-button-login" type="button" className="button full">
                    Log in
                  </button>
                </Link>
              </div>
              <div className="welcome-view__button-signup">
                <Link to="/signup">
                  <button data-testid="welcome-view-button-signup" type="button" className="button button-ghost full">
                    Sign up
                  </button>
                </Link>
              </div>
              <small className="welcome-view__terms-conditions" data-testid="welcome-view__terms-conditions">
                By signing up, you agree to our
                <a target="_blank" href="/">Terms and Conditions</a> and <a target="_blank" href="/">
                  Privacy Policy
                </a>.
              </small>
            </div>
          </div>
          <div className="col-md-3"></div>
        </div>
      </div>
    </div>
  )
}

export default LandingPage;