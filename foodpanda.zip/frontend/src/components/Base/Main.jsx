import React from 'react'
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCookies } from 'react-cookie';
import LandingPageNav from '../authentication/LandingPageNav'
import Hero from './Hero/Hero'
import './Main.css'
import HomeVendor from './Home/HomeVendor';
import Cities from './Home/Cities';

function Main() {
  const [token] = useCookies(['myToken']);
  const Navigate = useNavigate();

  useEffect(() => {
    return () => {
      String(token['myToken']) === 'undefined' ? Navigate('/') : Navigate('/main')
    };
  }, [token]);

  return (
    <div>
      <LandingPageNav show="block" />
      <Hero />
      <HomeVendor />
      <Cities />
    </div>
  )
}

export default Main;