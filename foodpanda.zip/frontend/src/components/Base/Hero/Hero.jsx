import React from 'react'
import HeroForm from './HeroForm';
import './Hero.css'

function Hero() {
    return (
        <div className="hero-container">
            <div className="row">
                <div className="col-md-8">
                    <div className="hero-left">
                        <div className="hero-section-text mb-5">
                            <div className="container">
                                <h1>
                                    It's the food and groceries you love, delivered
                                </h1>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="hero-background">
                    </div>
                </div>
            </div>
            <div className="row justify-content-center align-items-center g-2">
                <div className="col-md-11 form-component-container">
                    <HeroForm />
                </div>
                <div className="col-md-1">
                </div>
            </div>
        </div>
    )
}

export default Hero;