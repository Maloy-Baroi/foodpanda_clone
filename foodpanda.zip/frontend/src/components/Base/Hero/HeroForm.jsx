import React from 'react'
import './HeroForm.css'

function HeroForm() {
    return (
        <div className="heroForm-outer-container">
            <div className="form-context">
                <div className="input-wrapper">
                    <input type="text" id="user" required />
                    <label htmlFor="user">Enter Your Address</label>
                    <div className="button-container">
                        <button type="submit" className="button ml-3">
                            Delivery
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default HeroForm;