import React from 'react'

function ItemHeaderSubtitle(props) {
    return (
        <div>
            <h2 className="section-headline full-container">
                <span className="headline-subtitle">
                    {props.title}
                </span>
            </h2>
        </div>
    )
}

export default ItemHeaderSubtitle;