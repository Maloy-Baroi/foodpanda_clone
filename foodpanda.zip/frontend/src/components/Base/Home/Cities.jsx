import React from 'react'
import { useEffect, useState } from 'react'
import './Cities.css'
import OneCity from './OneCity'
import ItemHeaderSubtitle from '../Home/ItemHeaderSubtitle'

function Cities() {
    const [cities, setCities] = useState([]);
    useEffect(() => {
        fetch('http://localhost:8000/city-api-view/', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        })
            .then(resp => resp.json())
            .then(resp => {
                setCities(resp)
            })
            .catch(error => console.log(error))
    }, []);

    return (
        <div style={{ "margin": "260px 0 100px" }}>
            <section className="container">
                <ItemHeaderSubtitle title="Find us in these cities and many more!" />
            </section>
            <div className="container">
                <div className="row">
                    <OneCity allCities={cities} />   
                </div>
            </div>
        </div>
    )
}

export default Cities;