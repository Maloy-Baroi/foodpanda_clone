import React from 'react';
import './OneCity.css'


function OneCity(props) {
    return (
        <div>
            {props.allCities && props.allCities.map(city => {
                return (
                    <div className="col-md-3 zoom-effect-container" key={city.id}>
                        <div className="image-card">
                            <img src={city.images} alt={city.city} />
                            <div className="onecity-text">
                                <span>{city.city}</span>
                                <button type="button" className='goButton'>
                                    <svg className="svg-stroke-container" aria-hidden="true" focusable="false" height="18" viewBox="0 0 20 18" width="20" xmlns="http://www.w3.org/2000/svg"> <g fill="none" fillRule="evenodd" stroke="#FFFFFF" strokeLinecap="round" strokeWidth="2" transform="translate(1 1)"> <path d="M0,8 L17.5,8"></path> <polyline points="4.338 13.628 15.628 13.628 15.628 2.338" strokeLinejoin="round" transform="rotate(-45 9.983 7.983)"></polyline> </g> </svg>
                                </button>
                            </div>
                            <div className="hover-over-design">
                                <span className="city-letter" aria-hidden="true">
                                    {city.starts_with}
                                </span>
                            </div>
                        </div>
                    </div>
                )
            })}
        </div>
    );
}

export default OneCity;
