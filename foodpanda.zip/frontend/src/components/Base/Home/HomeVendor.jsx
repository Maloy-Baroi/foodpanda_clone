import React from 'react'
import { Link } from 'react-router-dom';
import './HomeVendor.css'
import ItemHeaderSubtitle from '../Home/ItemHeaderSubtitle';

function HomeVendor() {
    return (
        <div className="mt-5">
            <section className="home-vendor">
                <div className="container">
                    <ItemHeaderSubtitle title="You prepare the food, we handle the rest" />
                </div>
                <div className="home-section-vendor">
                    <div className="b-lazy home-section-vendor-image b-loaded b-loaded">
                    </div>
                    <div className="full-container">
                        <div className="home-section-vendor-content">
                            <p className="vendor-title">
                                List your restaurant or shop on foodpanda
                            </p>
                            <p className="vendor-content" style={{
                                "paddingTop": "12px"
                            }}>
                                Would you like millions of new customers to enjoy your amazing food and groceries? So would we!
                                <span style={{
                                    "display": "block",
                                    "height": "12px"
                                }}></span>
                                It's simple: we list your menu and product lists online, help you process orders, pick them up,
                                and deliver them to hungry pandas – in a heartbeat!
                                <span style={{
                                    "display": "block",
                                    "height": "12px"
                                }}></span>
                                Interested? Let's start our partnership today!
                            </p>

                            <Link className="getStartedButton home-section-vendor-button js-ripple" id="cta_banner_vendor_onboarding">
                                Get started
                                <i className="ripple"></i>
                            </Link>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    )
}

export default HomeVendor;