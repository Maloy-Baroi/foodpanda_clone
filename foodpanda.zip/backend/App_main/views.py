from django.shortcuts import render
from rest_framework.generics import ListAPIView, ListCreateAPIView, RetrieveUpdateAPIView, RetrieveDestroyAPIView, \
    CreateAPIView, DestroyAPIView
from rest_framework.permissions import IsAuthenticated, AllowAny
from App_main.models import *
from App_main.serializers import *


# Create your views here.
class CityAPIView(ListAPIView):
    # permission_classes = [IsAuthenticated, ]
    permission_classes = [AllowAny, ]
    queryset = AllCitiesModel.objects.all().order_by('city')
    serializer_class = AllCitiesModelSerializer
