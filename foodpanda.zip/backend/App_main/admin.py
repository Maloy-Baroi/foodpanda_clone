from django.contrib import admin
from App_main.models import *

# Register your models here.
admin.site.register(AllCitiesModel)
