from django.urls import path
from App_main.views import *

app_name = 'App_main'

urlpatterns = [
    path('city-api-view/', CityAPIView.as_view()),
]

