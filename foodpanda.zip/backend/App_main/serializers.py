from dataclasses import fields
from rest_framework import serializers
from App_main.models import *


class AllCitiesModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = AllCitiesModel
        fields = "__all__"
