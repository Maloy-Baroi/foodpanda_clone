from distutils.command.upload import upload
from django.db import models

# Create your models here.
class AllCitiesModel(models.Model):
    city = models.CharField(max_length=255)
    starts_with = models.CharField(max_length=2, blank=True)
    images = models.ImageField(upload_to="my_city/")

