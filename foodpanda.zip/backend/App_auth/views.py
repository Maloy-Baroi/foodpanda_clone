from django.shortcuts import render
from rest_framework.generics import *
from rest_framework.permissions import AllowAny
from rest_framework.decorators import api_view
from rest_framework_simplejwt.views import TokenObtainPairView
from App_auth.models import *
from App_auth.serializers import *
from django.contrib.auth import logout
from django.http import HttpResponse, JsonResponse
from rest_framework.decorators import action
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework import viewsets, status


# Create your views here.
class RegisterAPIView(CreateAPIView):
    queryset = CustomUser.objects.all()
    permission_classes = (AllowAny, )
    serializer_class = RegisterSerializer


# @api_view(['POST', 'GET'])
# def login_view(request):

@api_view(['POST'])
def logout_view(request):
    logout(request)
    return JsonResponse({"Loggout": "You have been logged out."}, safe=False)



