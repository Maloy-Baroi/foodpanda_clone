from django.urls import path
from App_auth.views import *
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from rest_framework.authtoken.views import obtain_auth_token


app_name = 'App_auth'

urlpatterns = [
    path('signup/', RegisterAPIView.as_view()),
    path('login/token/', TokenObtainPairView.as_view()),
    path('login/token/refresh/', TokenRefreshView.as_view()),
    path('logout/', logout_view),
]

